package com.example.restservice;

public class Greeting {

	private final long id;
	private final String content;
        private final String ipclient;

	public Greeting(long id, String content, String ipclient) {
		this.id = id;
		this.content = content;
		this.ipclient = ipclient;
	}

	public long getId() {
		return id;
	}

	public String getContent() {
		return content;
	}
        
	public String getIpclient() {
                return ipclient;
        }
}
