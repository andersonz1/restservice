package com.example.restservice;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.concurrent.atomic.AtomicLong;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.beans.factory.annotation.Autowired;
import javax.servlet.http.HttpServletRequest;

@RestController
public class GreetingController {
        private static final String template = "Hello, %s!";
        private final AtomicLong counter = new AtomicLong();
        private static final String[] HEADERS_TO_TRY = {
        	"X-Forwarded-For",
                "Proxy-Client-IP",
                "WL-Proxy-Client-IP",
                "HTTP_X_FORWARDED_FOR",
                "HTTP_X_FORWARDED",
                "HTTP_X_CLUSTER_CLIENT_IP",
                "HTTP_CLIENT_IP",
                "HTTP_FORWARDED_FOR",
                "HTTP_FORWARDED",
                "HTTP_VIA",
                "REMOTE_ADDR" };

	private  String getClientIpAddress(HttpServletRequest req) {
        	for (String header : HEADERS_TO_TRY) {
                String ip = req.getHeader(header);
                if (ip != null && ip.length() != 0 && !"unknown".equalsIgnoreCase(ip)) {
                	return ip;}
               	}
                return req.getRemoteAddr();
        }

        @Autowired(required = true)
        private HttpServletRequest  request;

	@CrossOrigin(origins = "*", allowedHeaders = "*")

	@GetMapping("/greeting")
	public Greeting greeting(@RequestParam(value = "name", defaultValue = "IBM Lab Services") String name) {
//		String clientIp = request.getHeader("X-FORWARDED-FOR");
//		if (clientIp == null) {
//			clientIp = request.getRemoteAddr();
//		}
//		String clientIp = request.getRemoteAddr();

		String clientIp = getClientIpAddress(request);	
		return new Greeting(counter.incrementAndGet(), String.format(template, name), clientIp);
	}	
}
